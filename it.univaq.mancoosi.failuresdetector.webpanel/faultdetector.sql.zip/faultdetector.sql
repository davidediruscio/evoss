-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 06, 2011 at 05:32 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `faultdetector`
--

-- --------------------------------------------------------

--
-- Table structure for table `ass_jarquery2fault`
--

CREATE TABLE IF NOT EXISTS `ass_jarquery2fault` (
  `ID` int(6) NOT NULL AUTO_INCREMENT,
  `idfirst` int(6) NOT NULL,
  `idsecond` int(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ass_jarquery2fault`
--

INSERT INTO `ass_jarquery2fault` (`ID`, `idfirst`, `idsecond`) VALUES
(1, 27, 13);

-- --------------------------------------------------------

--
-- Table structure for table `ass_oclqueries2keywords`
--

CREATE TABLE IF NOT EXISTS `ass_oclqueries2keywords` (
  `ID` int(6) NOT NULL AUTO_INCREMENT,
  `idfirst` int(6) NOT NULL,
  `idsecond` int(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=78 ;

--
-- Dumping data for table `ass_oclqueries2keywords`
--

INSERT INTO `ass_oclqueries2keywords` (`ID`, `idfirst`, `idsecond`) VALUES
(70, 51, 9),
(69, 51, 8),
(68, 51, 7),
(67, 50, 8),
(66, 50, 7),
(72, 52, 15),
(71, 52, 7),
(74, 53, 16),
(73, 53, 7),
(76, 54, 18),
(75, 54, 17),
(77, 54, 19);

-- --------------------------------------------------------

--
-- Table structure for table `ass_oclquery2fault`
--

CREATE TABLE IF NOT EXISTS `ass_oclquery2fault` (
  `ID` int(6) NOT NULL AUTO_INCREMENT,
  `idfirst` int(6) NOT NULL,
  `idsecond` int(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `ass_oclquery2fault`
--

INSERT INTO `ass_oclquery2fault` (`ID`, `idfirst`, `idsecond`) VALUES
(1, 12, 3),
(2, 12, 4),
(3, 13, 5),
(4, 13, 6),
(5, 14, 7),
(6, 14, 8),
(7, 15, 9),
(8, 15, 10),
(9, 16, 11),
(11, 53, 11),
(12, 50, 3),
(13, 53, 5),
(14, 54, 4),
(15, 52, 5),
(16, 56, 14),
(17, 59, 13),
(18, 64, 15);

-- --------------------------------------------------------

--
-- Table structure for table `ass_solution2fault`
--

CREATE TABLE IF NOT EXISTS `ass_solution2fault` (
  `ID` int(6) NOT NULL AUTO_INCREMENT,
  `idfirst` int(6) NOT NULL,
  `idsecond` int(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `ass_solution2fault`
--

INSERT INTO `ass_solution2fault` (`ID`, `idfirst`, `idsecond`) VALUES
(10, 6, 3),
(11, 7, 4),
(12, 8, 5),
(13, 7, 6),
(14, 8, 7),
(15, 8, 8),
(16, 9, 9),
(17, 9, 10),
(18, 6, 11),
(19, 6, 12),
(20, 10, 9),
(21, 10, 10),
(24, 6, 12);

-- --------------------------------------------------------

--
-- Table structure for table `conf_findfield`
--

CREATE TABLE IF NOT EXISTS `conf_findfield` (
  `ID` int(2) NOT NULL AUTO_INCREMENT,
  `mytable` varchar(40) NOT NULL,
  `myfield` varchar(40) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `conf_findfield`
--

INSERT INTO `conf_findfield` (`ID`, `mytable`, `myfield`) VALUES
(1, 'fault', 'idtext'),
(2, 'findfield', 'mytable'),
(3, 'oclquery', 'name'),
(4, 'solution', 'text'),
(5, 'users', 'nickname'),
(8, 'keywords', 'keyword'),
(9, 'jarquery', 'file');

-- --------------------------------------------------------

--
-- Table structure for table `fault`
--

CREATE TABLE IF NOT EXISTS `fault` (
  `ID` int(7) NOT NULL AUTO_INCREMENT,
  `idtext` varchar(40) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IDtext` (`idtext`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `fault`
--

INSERT INTO `fault` (`ID`, `idtext`, `description`) VALUES
(13, 'Missing MimeType Handlers', 'Some MimeType handler is missing in your system, thus you are not able to open some specific files.'),
(14, 'Missing Alternative', 'Some alternative is missing in your system.'),
(15, 'Configuration files with non-root access', 'Some configuration files in your system can be edited by non-root users.');

-- --------------------------------------------------------

--
-- Table structure for table `jarquery`
--

CREATE TABLE IF NOT EXISTS `jarquery` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `file` tinytext NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `jarquery`
--

INSERT INTO `jarquery` (`ID`, `name`, `description`, `file`) VALUES
(22, 'Missing files', 'Missing files on the real file system are noticed according to the information contained in the configuration model', 'missingFiles.jar'),
(26, 'Missing Configuration files', 'It checks for missing configuration files', 'MissingConfigurationFiles.jar'),
(27, 'Missing MimeType Handlers', '', 'MissingMimeTypeHandlers.jar');

-- --------------------------------------------------------

--
-- Table structure for table `keywords`
--

CREATE TABLE IF NOT EXISTS `keywords` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `keywords`
--

INSERT INTO `keywords` (`ID`, `keyword`) VALUES
(8, 'SelectNameEqapt'),
(7, 'InstalledPackageallInstances'),
(9, 'InstalledSizeEq5200'),
(13, 'InstalledSizeEq1000'),
(14, 'SelectNameEqapzt'),
(15, 'ExistsInstalledSizeLt85'),
(16, 'ExistsNameEqa'),
(17, 'ConfigurationallInstances'),
(18, 'CollectInstalledPackages'),
(19, 'ExistsNameEqapt');

-- --------------------------------------------------------

--
-- Table structure for table `oclquery`
--

CREATE TABLE IF NOT EXISTS `oclquery` (
  `ID` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `query` text NOT NULL,
  `author` varchar(16) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `oclquery`
--

INSERT INTO `oclquery` (`ID`, `name`, `query`, `author`) VALUES
(65, 'Missing packages involved in implicit package dependencies', 'mancoosimm::PackageSetting.allInstances()->exists( e | e.dependences->exists (d | d.ownerPkg.oclIsTypeOf(''mancoosimm:: NotInstalledPackage'')))', 'Davide'),
(56, 'Alternative elements with missing current executable', 'mancoosimm::Alternative.allInstances()->exists(e | e.current.oclIsUndefined())', 'Davide'),
(57, 'Missing executable in a Service element', 'mancoosimm::Service.allInstances()->exists(e | e.executable.oclIsUndefined())', 'Davide'),
(58, 'Missing executbale in a Menu Entry element', 'mancoosimm::MenuEntry.allInstances()->exists(e | e.executable.oclIsUndefined())', 'Davide'),
(59, 'Missing executable in a MimeTypeHandler element', 'mancoosimm::MimeTypeHandler.allInstances()->exists(h | h.handler.oclIsUndefined())', 'Davide'),
(60, 'Existence of HalfConfiguredReinstRequiredPackage', 'mancoosimm::HalfConfiguredReinstRequiredPackage.allInstances()->size() > 0', 'Davide'),
(61, 'Existence of HalfInstalledReinstRequiredPackage', 'mancoosimm::HalfInstalledReinstRequiredPackage.allInstances()->size() > 0', 'Davide'),
(62, 'Existence of HalfConfiguredPackage', 'mancoosimm::HalfConfiguredPackage.allInstances()->size() > 0', 'Davide'),
(63, 'Existence of HalfInstalledPackage', 'mancoosimm::HalfInstalledPackage.allInstances()->size() > 0', 'Davide'),
(64, 'Existence of configuration files with non-root permissions', 'mancoosimm::PackageSetting.allInstances()->exists(e | e.files->exists(f | (f.owner.name <> ''root'')) )', 'Davide');

-- --------------------------------------------------------

--
-- Table structure for table `solution`
--

CREATE TABLE IF NOT EXISTS `solution` (
  `ID` int(8) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `solution`
--

INSERT INTO `solution` (`ID`, `text`) VALUES
(6, 'Install the package so to fix the implicit dependences, or to remove the package that gives place to the problem.'),
(7, 'Remove or reinstall the package.'),
(8, 'Reinstall the package even if the user wants to remove it because of the Reinst required flag.'),
(11, 'Specify the correct executable, or fix the reference to it.'),
(12, 'Add a correct reference to an executable or to remove the entry of the menu.'),
(13, 'Restore the executable or remove the service.'),
(14, 'Fix the location used by the alternative or reinstall the executable required by the alternative, or remove the alternative entry.'),
(15, 'Change the owner of the configuration file(s).'),
(16, 'Restore the missing configuration file(s).'),
(17, 'Reinstall the missing service.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(16) NOT NULL,
  `password` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `nickname` (`nickname`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `nickname`, `password`, `email`) VALUES
(6, 'admin', 'admin', 'davide.diruscio@univaq.it');
